import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Encourage sustained forward motion by rewarding the distance traveled per time step squared
    distance_reward = self._forward_reward_weight * (x_velocity ** 2)

    # Introduce a reward component for maintaining a target average velocity over a certain window
    if hasattr(self, 'velocity_history'):
        self.velocity_history.append(x_velocity)
        if len(self.velocity_history) > 5:  # Maintain history of last 5 velocities
            self.velocity_history.pop(0)
        average_velocity = np.mean(self.velocity_history)
        average_velocity_reward = 0.5 * (average_velocity ** 2)  # Favor keeping a stable high velocity
    else:
        self.velocity_history = [x_velocity]
        average_velocity_reward = 0

    # Reward for minimizing jerkiness in control actions
    if hasattr(self, 'previous_action'):
        smoothness_reward = -np.sum(np.square(action - self.previous_action))  # Negative reward for jerkiness
    else:
        smoothness_reward = 0  # No penalty on the first step

    # Store current action for next step comparison
    self.previous_action = action

    # Control penalty to minimize energy expenditure 
    control_penalty = self._ctrl_cost_weight * np.sum(np.square(action))

    # Healthy state reward, rewarding the maintenance of a healthy posture
    health_bonus = self.healthy_reward

    # Combine rewards and penalties to form the total reward
    total_reward = distance_reward + average_velocity_reward + smoothness_reward - control_penalty + health_bonus

    # Create a dictionary to store individual components of the reward for monitoring and analysis
    reward_info = {
        'distance_reward': distance_reward,
        'average_velocity_reward': average_velocity_reward,
        'smoothness_reward': smoothness_reward,
        'control_penalty': control_penalty,
        'health_bonus': health_bonus,
        'total_reward': total_reward
    }

    return total_reward, reward_info

import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Reward based on the forward velocity with an exponential growth to prioritize higher speeds
    forward_velocity_reward = self._forward_reward_weight * (np.exp(x_velocity) - 1)

    # Reward for maintaining a steady acceleration: smaller changes in forward velocity are favored
    if hasattr(self, 'previous_velocity'):
        acceleration_reward = -np.sum(np.square(x_velocity - self.previous_velocity))  # Penalizing rapid changes
    else:
        acceleration_reward = 0  # No penalty on the first step
    self.previous_velocity = x_velocity

    # Reward for the efficiency of action, discouraging excessive torque changes
    if hasattr(self, 'previous_action'):
        torque_smoothness_reward = -np.sum(np.abs(action - self.previous_action))  # Favoring continuity in actions
    else:
        torque_smoothness_reward = 0  # No penalty on the first step
    self.previous_action = action

    # Control penalty for energy efficiency
    control_penalty = self._ctrl_cost_weight * np.sum(np.square(action))

    # Healthy state reward, keeping the hopper upright and within healthy parameters
    health_bonus = self.healthy_reward

    # Total reward calculation
    total_reward = forward_velocity_reward + acceleration_reward + torque_smoothness_reward - control_penalty + health_bonus

    # Prepare information dictionary for debugging and analysis
    reward_info = {
        'forward_velocity_reward': forward_velocity_reward,
        'acceleration_reward': acceleration_reward,
        'torque_smoothness_reward': torque_smoothness_reward,
        'control_penalty': control_penalty,
        'health_bonus': health_bonus,
        'total_reward': total_reward
    }

    return total_reward, reward_info

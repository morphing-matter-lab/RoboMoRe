import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Encourage forward velocity with a quadratic scaling for greater emphasis on higher velocities
    forward_velocity_reward = self._forward_reward_weight * (x_velocity ** 2)

    # Smoothness penalty to reduce abrupt changes in action, promoting control over torque application
    if hasattr(self, 'previous_action'):
        smoothness_penalty = np.sum(np.abs(action - self.previous_action))  # Absolute difference favors minor adjustments
    else:
        smoothness_penalty = 0
    self.previous_action = action

    # Additional control costs to discourage excessive torque usage, keeping energy expenditure in check
    control_penalty = self._ctrl_cost_weight * np.sum(np.square(action))

    # Health bonus for maintaining a specified healthy dynamic state
    health_bonus = self.healthy_reward

    # Total reward combining all components, with adjustments for penalties
    total_reward = forward_velocity_reward - smoothness_penalty - control_penalty + health_bonus

    # Reward information dictionary for analysis and debugging purposes
    reward_info = {
        'forward_velocity_reward': forward_velocity_reward,
        'smoothness_penalty': smoothness_penalty,
        'control_penalty': control_penalty,
        'health_bonus': health_bonus,
        'total_reward': total_reward
    }

    return total_reward, reward_info

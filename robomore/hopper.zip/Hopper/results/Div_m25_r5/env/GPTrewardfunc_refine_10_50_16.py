import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Forward reward based on the x_velocity
    forward_reward = self._forward_reward_weight * x_velocity
    
    # Healthy reward to promote staying within healthy state
    healthy_reward = self.healthy_reward
    
    # Time penalty to discourage long episodes
    time_penalty = -0.05 * self.dt  # Encourages quicker completion of each step
    
    # Normalize and decay the control effort to avoid heavy penalization
    control_effort = self.control_cost(action)
    normalized_ctrl_cost = np.clip(np.exp(-self._ctrl_cost_weight * control_effort), 0, 1)
    
    # Cumulative motion reward based on distance traveled
    distance_reward = (self.data.qpos[0] - self.init_qpos[0]) * self._forward_reward_weight
    
    # Total reward calculation
    reward = forward_reward + healthy_reward + time_penalty + normalized_ctrl_cost + distance_reward

    reward_info = {
        "reward_forward": forward_reward,
        "reward_ctrl": normalized_ctrl_cost,
        "reward_survive": healthy_reward,
        "reward_time": time_penalty,
        "reward_distance": distance_reward,
    }

    return reward, reward_info

import numpy as np 
def _get_rew(self, x_velocity: float, action):
    forward_reward = self._forward_reward_weight * x_velocity
    healthy_reward = self.healthy_reward
    time_penalty = -0.01  # Small negative reward to encourage faster completion
    control_effort = self.control_cost(action)
    
    # Implement exponential decay to the control cost to mitigate high penalization for control
    ctrl_cost = np.exp(-self._ctrl_cost_weight * control_effort)

    # Total reward calculation
    reward = forward_reward + healthy_reward + time_penalty + ctrl_cost

    reward_info = {
        "reward_forward": forward_reward,
        "reward_ctrl": ctrl_cost,
        "reward_survive": healthy_reward,
        "reward_time": time_penalty,
    }

    return reward, reward_info

import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Penalty for large changes in action to promote consistency
    if hasattr(self, 'last_action'):
        action_change_penalty = np.sum(np.square(action - self.last_action))
    else:
        action_change_penalty = 0  # No penalty for the initial action
    self.last_action = action

    # Reward for maintaining forward velocity, incentivized with a quadratic term for high speeds
    forward_velocity_reward = self._forward_reward_weight * (x_velocity ** 2)

    # Additional bonus for high velocities, cubed to prioritize rapid advancement drastically
    high_speed_boost = self._forward_reward_weight * (x_velocity ** 3) * 0.1  # Adjusting scale to prevent overflow

    # Encouragement to remain healthy and balanced as per defined state parameters
    health_bonus = self.healthy_reward

    # Control penalty to discourage overexertion of torques
    control_penalty = self._ctrl_cost_weight * np.sum(np.square(action))

    # Total reward calculation
    total_reward = forward_velocity_reward + high_speed_boost - action_change_penalty + health_bonus - control_penalty

    # Reward information for analysis and debugging
    reward_info = {
        'action_change_penalty': action_change_penalty,
        'forward_velocity_reward': forward_velocity_reward,
        'high_speed_boost': high_speed_boost,
        'health_bonus': health_bonus,
        'control_penalty': control_penalty,
        'total_reward': total_reward
    }

    return total_reward, reward_info

import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Reward for consistent forward velocity
    consistent_velocity_reward = self._forward_reward_weight * (x_velocity) ** 2  # Emphasizing higher speeds
    
    # Encourage minimal change in action to promote rhythmic motion patterns
    if hasattr(self, 'previous_action'):
        action_smoothness_reward = -np.sum(np.abs(action - self.previous_action))  # Favor smaller changes
    else:
        action_smoothness_reward = 0  # No penalty on the first step
    self.previous_action = action
    
    # Health reward for staying within the healthy state parameters
    health_bonus = self.healthy_reward
    
    # Penalty for using excessive action values to promote efficiency
    control_penalty = self._ctrl_cost_weight * np.sum(np.square(action))
    
    # Total reward composition
    total_reward = consistent_velocity_reward + action_smoothness_reward + health_bonus - control_penalty
    
    # Reward information for monitoring
    reward_info = {
        'consistent_velocity_reward': consistent_velocity_reward,
        'action_smoothness_reward': action_smoothness_reward,
        'health_bonus': health_bonus,
        'control_penalty': control_penalty,
        'total_reward': total_reward
    }
    
    return total_reward, reward_info

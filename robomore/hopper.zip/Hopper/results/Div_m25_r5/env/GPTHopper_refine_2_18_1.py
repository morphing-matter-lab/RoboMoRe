import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Reward for moving forward (right)
    forward_reward = self._forward_reward_weight * x_velocity

    # Reward for maintaining a healthy state
    healthy_reward = self.healthy_reward

    # Control cost to penalize excessive action (torque) usage
    ctrl_cost = self.control_cost(action)

    # Compute the total reward: encouraging forward motion and health while penalizing large control signals
    reward = forward_reward + healthy_reward - ctrl_cost

    # Organize the reward components for detailed analysis
    reward_info = {
        "reward_forward": forward_reward,
        "reward_ctrl": -ctrl_cost,
        "reward_survive": healthy_reward,
    }

    return reward, reward_info

import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Reward for forward speed, adding a quadratic term to emphasize higher speeds even more
    speed_reward = self._forward_reward_weight * (x_velocity ** 2)

    # Enhance the reward for maintaining a target velocity range to encourage consistent movement
    target_velocity = 1.5  # Example target velocity
    target_velocity_reward = max(0, (1 - abs(x_velocity - target_velocity)))

    # Smoothness reward: encourage a more gradual application of actions (torque)
    if hasattr(self, 'previous_action'):
        action_smoothness_reward = -np.sum(np.abs(action - self.previous_action))  # Encouraging smooth transitions
    else:
        action_smoothness_reward = 0
    
    self.previous_action = action  # store current action for next step
    
    # Control cost penalty encouraging energy-efficient actions
    control_cost = self._ctrl_cost_weight * np.sum(np.square(action))

    # Healthy state reward, maintaining a good posture and balance
    health_bonus = self.healthy_reward

    # Total reward combining all components
    total_reward = speed_reward + target_velocity_reward + action_smoothness_reward - control_cost + health_bonus

    # Reward information dictionary for monitoring and debugging
    reward_info = {
        'speed_reward': speed_reward,
        'target_velocity_reward': target_velocity_reward,
        'action_smoothness_reward': action_smoothness_reward,
        'control_cost': control_cost,
        'health_bonus': health_bonus,
        'total_reward': total_reward
    }

    return total_reward, reward_info

import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Reward for maintaining a healthy balance
    balance_reward = self.healthy_reward

    # Reward for velocity encouraging the hopper to move forward efficiently, using a cubic function to emphasize higher speeds even more
    velocity_reward = self._forward_reward_weight * (x_velocity ** 3)

    # Encouragement for consistent application of torque to promote stable movements
    if hasattr(self, 'previous_action'):
        torque_stability_reward = -np.sum(np.abs(action - self.previous_action))  # Penalizes drastic changes in action
    else:
        torque_stability_reward = 0  # No penalty on the first step
    self.previous_action = action

    # Penalty for control usage to discourage excessive energy expenditure
    control_penalty = self._ctrl_cost_weight * np.sum(np.square(action))

    # Introduce a small bonus for achieving target velocities to further encourage faster movements
    target_velocity_bonus = 0.5 if x_velocity > 1.0 else 0.0  # Bonus if velocity exceeds a certain threshold (1.0)

    # Full reward calculation: encourage forward movement and health, penalize torque instability and high control cost
    total_reward = balance_reward + velocity_reward + torque_stability_reward - control_penalty + target_velocity_bonus

    # Reward information breakdown for monitoring and debugging
    reward_info = {
        'balance_reward': balance_reward,
        'velocity_reward': velocity_reward,
        'torque_stability_reward': torque_stability_reward,
        'control_penalty': control_penalty,
        'target_velocity_bonus': target_velocity_bonus,
        'total_reward': total_reward
    }

    return total_reward, reward_info

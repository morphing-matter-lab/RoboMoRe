import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Calculate the forward reward proportional to the hopper's x-axis velocity
    forward_reward = self._forward_reward_weight * x_velocity
    
    # Obtain the reward for maintaining a healthy state
    healthy_reward = self.healthy_reward
    
    # Sum the rewards from forward motion and being healthy
    rewards = forward_reward + healthy_reward
    
    # Compute the cost of control to penalize excessive use of actuator torques
    ctrl_cost = self.control_cost(action)
    
    # Sum all costs (here, control costs)
    costs = ctrl_cost
    
    # Calculate total reward by subtracting costs from rewards
    reward = rewards - costs
    
    # Prepare detailed information about each component of the reward for diagnostic purposes
    reward_info = {
        "reward_forward": forward_reward,
        "reward_ctrl": -ctrl_cost,
        "reward_survive": healthy_reward,
    }
    
    return reward, reward_info

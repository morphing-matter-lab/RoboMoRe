import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Reward for consistently maintaining forward velocity over time, encouraging steady hops
    velocity_target = 2.0  # Set a target velocity for optimal hopping
    consistency_reward = -np.abs(x_velocity - velocity_target)  # Penalize deviations from the target velocity

    # Reward for forward speed with a cubic boost to give even more emphasis on higher speeds
    cubic_speed_reward = self._forward_reward_weight * (x_velocity ** 3)  # Cubic scaling to prioritize higher speeds significantly

    # Smoothness reward to favor small variations in control actions
    if hasattr(self, 'previous_action'):
        smoothness_reward = -np.sum(np.abs(action - self.previous_action))  # Encourage small changes between consecutive actions
    else:
        smoothness_reward = 0  # No penalty on the first step
    
    # Store current action for future comparisons
    self.previous_action = action

    # Control cost to minimize excessive torque application
    control_penalty = self._ctrl_cost_weight * np.sum(np.square(action))

    # Healthy state reward for maintaining balance and upright state
    health_bonus = self.healthy_reward

    # Total reward calculation
    total_reward = consistency_reward + cubic_speed_reward + smoothness_reward - control_penalty + health_bonus

    # Reward information breakdown for analysis
    reward_info = {
        'consistency_reward': consistency_reward,
        'cubic_speed_reward': cubic_speed_reward,
        'smoothness_reward': smoothness_reward,
        'control_penalty': control_penalty,
        'health_bonus': health_bonus,
        'total_reward': total_reward
    }

    return total_reward, reward_info

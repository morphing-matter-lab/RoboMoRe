import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Reward for fast forward movement with a quadratic scaling to favor higher speeds
    forward_reward = self._forward_reward_weight * (x_velocity ** 2)

    # Penalize rapid changes in action to smooth the hopping motion
    if hasattr(self, 'previous_action'):
        smoothness_penalty = np.sum(np.abs(np.diff(action)))  # Encourage smoother transitions
    else:
        smoothness_penalty = 0
    self.previous_action = action

    # Control cost to discourage excessive torque usage
    control_penalty = self._ctrl_cost_weight * np.sum(np.square(action))

    # Healthy reward to encourage maintaining within healthy state parameters
    health_bonus = self.healthy_reward

    # Total reward calculation combining all components
    total_reward = forward_reward - smoothness_penalty - control_penalty + health_bonus

    # Reward information breakdown for debugging and analysis
    reward_info = {
        'forward_reward': forward_reward,
        'smoothness_penalty': smoothness_penalty,
        'control_penalty': control_penalty,
        'health_bonus': health_bonus,
        'total_reward': total_reward
    }

    return total_reward, reward_info

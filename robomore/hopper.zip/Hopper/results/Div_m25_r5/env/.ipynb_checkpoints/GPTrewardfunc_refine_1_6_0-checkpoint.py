import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Reward for achieving a baseline forward velocity
    base_speed_reward = self._forward_reward_weight * x_velocity
    
    # Exponential scaling for high speeds with a threshold to ensure a reward structure that does not penalize slower speeds too heavily
    high_speed_bonus = self._forward_reward_weight * (np.exp(x_velocity) - 1) if x_velocity > 1 else 0
    
    # Penalty for abrupt changes in action to encourage smoother hopping
    if hasattr(self, 'previous_action'):
        control_smoothness_penalty = -np.sum(np.abs(action - self.previous_action))
    else:
        control_smoothness_penalty = 0  # No penalty on the first action
    self.previous_action = action

    # Penalty for excessive control input to incentivize energy-efficient actions
    action_cost_penalty = self._ctrl_cost_weight * np.sum(np.square(action))

    # Health reward for maintaining a healthy state during hopping
    health_reward = self.healthy_reward

    # Total reward calculation combining all components
    total_reward = base_speed_reward + high_speed_bonus + control_smoothness_penalty - action_cost_penalty + health_reward

    # Compile reward details for debugging
    reward_info = {
        'base_speed_reward': base_speed_reward,
        'high_speed_bonus': high_speed_bonus,
        'control_smoothness_penalty': control_smoothness_penalty,
        'action_cost_penalty': action_cost_penalty,
        'health_reward': health_reward,
        'total_reward': total_reward
    }

    return total_reward, reward_info

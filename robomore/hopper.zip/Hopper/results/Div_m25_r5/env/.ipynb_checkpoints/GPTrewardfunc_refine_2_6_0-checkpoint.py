import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Reward for progressive increases in speed - measure the change in forward velocity
    if hasattr(self, 'previous_velocity'):
        velocity_increase_reward = max(0, x_velocity - self.previous_velocity)
    else:
        velocity_increase_reward = 0
    self.previous_velocity = x_velocity

    # Utilize a cubic reward for velocity to heavily encourage higher speeds
    cubic_velocity_reward = self._forward_reward_weight * (x_velocity ** 3)

    # Penalize the absolute sum of actions to encourage minimal control usage
    control_efficiency_penalty = self._ctrl_cost_weight * np.sum(np.abs(action))

    # Healthy state maintenance reward
    health_maintenance_bonus = self.healthy_reward

    # Combine all the rewards and penalties
    total_reward = cubic_velocity_reward + velocity_increase_reward - control_efficiency_penalty + health_maintenance_bonus

    # Creating a dictionary of rewards for debug purposes
    reward_info = {
        'cubic_velocity_reward': cubic_velocity_reward,
        'velocity_increase_reward': velocity_increase_reward,
        'control_efficiency_penalty': control_efficiency_penalty,
        'health_maintenance_bonus': health_maintenance_bonus,
        'total_reward': total_reward
    }

    return total_reward, reward_info

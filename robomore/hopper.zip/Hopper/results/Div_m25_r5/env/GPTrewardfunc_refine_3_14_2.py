import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Reward for effective forward movement with a component for gaining momentum
    momentum_reward = self._forward_reward_weight * (x_velocity + (x_velocity ** 2) / 100)  # Encourages both speed and forward progression

    # Reward for maintaining balance and rhythmic action over time 
    if hasattr(self, 'previous_action'):
        rhythmic_balance_reward = -np.sum(np.abs(action - self.previous_action))  # Reward smooth transitions in action
    else:
        rhythmic_balance_reward = 0  # No penalty on the first step

    # Store the current action for the next step comparison
    self.previous_action = action

    # Control cost penalty to manage energy expenditure
    control_penalty = self._ctrl_cost_weight * np.sum(np.square(action))

    # Combine rewards: forward momentum, rhythmic actions, and penalty for control cost
    total_reward = momentum_reward + rhythmic_balance_reward - control_penalty + self.healthy_reward

    # Construct reward information for analysis
    reward_info = {
        'momentum_reward': momentum_reward,
        'rhythmic_balance_reward': rhythmic_balance_reward,
        'control_penalty': control_penalty,
        'health_bonus': self.healthy_reward,
        'total_reward': total_reward
    }

    return total_reward, reward_info

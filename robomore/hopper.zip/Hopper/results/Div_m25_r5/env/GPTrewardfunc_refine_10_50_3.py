import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Reward for forward speed, amplified to enhance its weight in total reward
    forward_reward = self._forward_reward_weight * (x_velocity ** 2)  # Squaring velocity to emphasize faster movements
    healthy_reward = self.healthy_reward
    
    # Introducing a penalty for excessive control actions to encourage energy-efficient movements
    ctrl_cost = self.control_cost(action)
    control_penalty = self._ctrl_cost_weight * np.sum(np.square(action - np.mean(action)))  # Encouraging consistent control efforts

    # Total reward calculation
    total_reward = forward_reward + healthy_reward - ctrl_cost - control_penalty

    # Normalize rewards for stability
    normalized_reward = np.tanh(total_reward)

    # Preparing the reward info for tracking
    reward_info = {
        "reward_forward": forward_reward,
        "reward_health": healthy_reward,
        "reward_control": -ctrl_cost,
        "reward_control_penalty": -control_penalty,
        "total_normalized_reward": normalized_reward,
    }

    return normalized_reward, reward_info

import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Reward for achieving high forward speed, penalizing less effective velocities
    forward_speed_reward = self._forward_reward_weight * (x_velocity**2)  # Reward quadratic growth with speed
    
    # Incentivize consistent action to enhance smoothness and rhythm in the hopper's movement
    if hasattr(self, 'previous_action'):
        rhythmic_smoothness_reward = -np.sum(np.abs(action - self.previous_action))  # Penalizes abrupt changes in actions
    else:
        rhythmic_smoothness_reward = 0
    self.previous_action = action  # Store current action for next comparison

    # Reward for maintaining a healthy posture, encouraging the hopper to stay upright
    health_bonus = self.healthy_reward  

    # Control cost penalty: Promote energy-efficient use of actuator torque
    control_penalty = self._ctrl_cost_weight * np.sum(np.square(action))

    # Combine all the components to compute the total reward
    total_reward = forward_speed_reward + rhythmic_smoothness_reward + health_bonus - control_penalty

    # Prepare a detailed reward information dictionary for analysis and debugging
    reward_info = {
        'forward_speed_reward': forward_speed_reward,
        'rhythmic_smoothness_reward': rhythmic_smoothness_reward,
        'health_bonus': health_bonus,
        'control_penalty': control_penalty,
        'total_reward': total_reward
    }

    return total_reward, reward_info

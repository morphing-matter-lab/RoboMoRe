import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Highly reward forward velocity
    forward_reward = self._forward_reward_weight * x_velocity

    # Survivor reward for maintaining a healthy state
    healthy_reward = self.healthy_reward

    # Combine the rewards
    rewards = forward_reward + healthy_reward

    # Control cost penalizes the magnitude of action to prevent erratic movements
    ctrl_cost = self.control_cost(action)
    
    # Total reward encouraged maximal forward movement with minimal control effort while staying healthy
    reward = rewards - ctrl_cost

    # Information dictionary of individual components for debugging purposes
    reward_info = {
        "reward_forward": forward_reward,
        "reward_ctrl": -ctrl_cost,
        "reward_survive": healthy_reward,
    }

    return reward, reward_info

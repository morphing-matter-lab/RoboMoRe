import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Reward for forward velocity, emphasizing higher speeds
    forward_reward = self._forward_reward_weight * x_velocity**2  # Squared reward for faster emphasizing
    
    # Reward for consistent control actions to reduce excessive changes
    if hasattr(self, 'previous_action'):
        consistency_reward = -np.sum(np.abs(action - self.previous_action))  # Encouraging smaller changes in actions
    else:
        consistency_reward = 0  # No penalty for the initial step

    # Store current action for the next step comparison
    self.previous_action = action

    # Encouraging a moderate pace of change in joint torques
    torque_smoothness_penalty = self._ctrl_cost_weight * np.sum(np.abs(np.diff(action))) * 0.5  # Small penalty for torque variations
    
    # Control costs to promote energy-efficient actions
    control_penalty = self._ctrl_cost_weight * np.sum(np.square(action))

    # Reward for maintaining a healthy state
    health_bonus = self.healthy_reward

    # Combine individual components for the total reward
    total_reward = forward_reward + consistency_reward - torque_smoothness_penalty - control_penalty + health_bonus

    # Prepare the reward information for monitoring
    reward_info = {
        'forward_reward': forward_reward,
        'consistency_reward': consistency_reward,
        'torque_smoothness_penalty': torque_smoothness_penalty,
        'control_penalty': control_penalty,
        'health_bonus': health_bonus,
        'total_reward': total_reward
    }

    return total_reward, reward_info

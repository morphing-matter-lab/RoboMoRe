import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Reward for forward movement, emphasizing acceleration to encourage faster hops
    forward_reward = self._forward_reward_weight * (x_velocity ** 1.5)  # Exponentially scaling the reward based on velocity

    # Additional reward for maintaining consistent hopping rhythms by rewarding based on the stability of the previous action
    if hasattr(self, 'previous_action'):
        consistency_reward = -np.sum(np.abs(action - self.previous_action))
    else:
        consistency_reward = 0  # No penalty on the first action

    # Store the current action to compare in the next step
    self.previous_action = action

    # Control penalty to discourage excessive force or energy use
    control_penalty = self._ctrl_cost_weight * np.sum(np.square(action))

    # Reward for health, encouraging the robot to stay within the defined healthy states
    health_bonus = self.healthy_reward

    # Total reward computation: combining the rewards and penalties
    total_reward = forward_reward + consistency_reward - control_penalty + health_bonus

    # Structured reward information for better insight during debugging
    reward_info = {
        'forward_reward': forward_reward,
        'consistency_reward': consistency_reward,
        'control_penalty': control_penalty,
        'health_bonus': health_bonus,
        'total_reward': total_reward
    }

    return total_reward, reward_info

import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Encourage continuous and smooth forward hopping motion
    if hasattr(self, 'previous_velocity'):
        velocity_change_reward = -np.abs(x_velocity - self.previous_velocity)  # Reward small changes in velocity
    else:
        velocity_change_reward = 0  # No penalty on the first step
    
    self.previous_velocity = x_velocity  # Update previous velocity for next step comparison

    # Reward for sustained forward motion with an additional bonus for speed
    speed_bonus = (x_velocity ** 2) * self._forward_reward_weight  # Quadratic scaling for high speeds
    
    # Penalty for abrupt changes in actions; encouraging smooth control inputs 
    if hasattr(self, 'previous_action'):
        action_smoothness_penalty = np.sum(np.abs(action - self.previous_action))  
    else:
        action_smoothness_penalty = 0 
        
    self.previous_action = action  # Store the current action for next comparison

    # Control cost to avoid excessive use of energy
    control_cost = self._ctrl_cost_weight * np.sum(np.square(action))
    
    # Healthy state reward reinforcing robotic health
    health_reward = self.healthy_reward
    
    # Total reward is a combination of smoothness, speed, health, minus penalties
    total_reward = speed_bonus + health_reward + velocity_change_reward - action_smoothness_penalty - control_cost
    
    # Reward information for debugging
    reward_info = {
        'speed_bonus': speed_bonus,
        'health_reward': health_reward,
        'velocity_change_reward': velocity_change_reward,
        'action_smoothness_penalty': action_smoothness_penalty,
        'control_cost': control_cost,
        'total_reward': total_reward
    }

    return total_reward, reward_info

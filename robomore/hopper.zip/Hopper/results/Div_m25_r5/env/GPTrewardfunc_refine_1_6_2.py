import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Encouraging balanced forward movement with a reward proportional to the square of velocity
    balanced_forward_reward = self._forward_reward_weight * (x_velocity ** 2)

    # Encouragement for minimal changes in control inputs (torque application)
    if hasattr(self, 'previous_action'):
        controlled_variation_penalty = np.sum(np.abs(action - self.previous_action))  # Penalizing abrupt changes
    else:
        controlled_variation_penalty = 0  # No penalty on the first step
    self.previous_action = action

    # Healthy state reward for keeping within defined parameters
    health_bonus = self.healthy_reward

    # Emphasizing energy efficiency by adding a penalty for excessive control (action) usage
    control_penalty = self._ctrl_cost_weight * np.sum(np.square(action))

    # Total reward computation ensuring different components contribute favorably
    total_reward = balanced_forward_reward - controlled_variation_penalty + health_bonus - control_penalty

    # Reward information for detailed tracking and monitoring
    reward_info = {
        'balanced_forward_reward': balanced_forward_reward,
        'controlled_variation_penalty': controlled_variation_penalty,
        'control_penalty': control_penalty,
        'health_bonus': health_bonus,
        'total_reward': total_reward
    }

    return total_reward, reward_info

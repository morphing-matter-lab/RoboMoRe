import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Reward for substantial forward movement, scaling with a power of the velocity to emphasize larger speeds.
    forward_reward = self._forward_reward_weight * (x_velocity ** 2)

    # Reward for maintaining a healthy upright position and state
    health_reward = self.healthy_reward

    # Penalize large changes in control actions to promote smooth transitions
    if hasattr(self, 'previous_action'):
        smoothness_penalty = -np.sum(np.abs(action - self.previous_action))  # Reward smooth actions
    else:
        smoothness_penalty = 0  # No penalty at the first step
    self.previous_action = action  # Store action for the next step

    # Control cost to deter excessive torque usage, promoting energy efficiency
    control_cost = self._ctrl_cost_weight * np.sum(np.square(action))

    # Introduce a bonus for rapid accelerations, rewarding quick changes in velocity
    acceleration_bonus = self._forward_reward_weight * np.clip((x_velocity - (self.previous_x_velocity if hasattr(self, 'previous_x_velocity') else 0)), 0, None)
    self.previous_x_velocity = x_velocity  # Store current velocity for the next step

    # Combine all components to establish the total reward
    total_reward = forward_reward + health_reward + smoothness_penalty + acceleration_bonus - control_cost

    # Prepare information dictionary for tracking reward components
    reward_info = {
        'forward_reward': forward_reward,
        'health_reward': health_reward,
        'smoothness_penalty': smoothness_penalty,
        'control_cost': control_cost,
        'acceleration_bonus': acceleration_bonus,
        'total_reward': total_reward
    }

    return total_reward, reward_info

import numpy as np 
def _get_rew(self, x_velocity: float, action):
    forward_reward = self._forward_reward_weight * x_velocity
    healthy_reward = self.healthy_reward
    # Reward for maintaining velocity increase
    velocity_increase = max(0, x_velocity - abs(self.prev_velocity))  # Reward sustained or increased speed
    self.prev_velocity = x_velocity  # Update the previous velocity for the next step 
    velocity_reward = velocity_increase * 0.5  # Scale the velocity increase reward
    
    # Penalty for excessive lateral movement (assuming lateral velocity is some other part of the state)
    lateral_velocity = abs(self.data.qvel[1])  # Assuming the lateral velocity is at index 1
    lateral_penalty = -lateral_velocity  # Penalize lateral movement
    
    ctrl_cost = self.control_cost(action)
    
    # Total reward calculation
    reward = forward_reward + healthy_reward + velocity_reward + lateral_penalty - ctrl_cost

    reward_info = {
        "reward_forward": forward_reward,
        "reward_velocity": velocity_reward,
        "reward_lateral": lateral_penalty,
        "reward_ctrl": -ctrl_cost,
        "reward_survive": healthy_reward,
    }

    return reward, reward_info

import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Reward for moving forward, positively scaled by the forward velocity
    forward_reward = self._forward_reward_weight * x_velocity
    
    # Reward for staying healthy (i.e., not falling down or out of predetermined healthy ranges)
    healthy_reward = self.healthy_reward
    
    # Combining rewards altogether
    rewards = forward_reward + healthy_reward

    # Calculate control cost which penalizes excessive use of control/torque to maintain efficiency
    ctrl_cost = self.control_cost(action)
    
    # Subtracting costs from rewards to form the final single reward value
    reward = rewards - ctrl_cost

    # Reward components breakdown for analysis and debugging
    reward_info = {
        "reward_forward": forward_reward,
        "reward_ctrl": -ctrl_cost,
        "reward_survive": healthy_reward,
    }

    # Return the total reward and the dictionary of individual reward components
    return reward, reward_info

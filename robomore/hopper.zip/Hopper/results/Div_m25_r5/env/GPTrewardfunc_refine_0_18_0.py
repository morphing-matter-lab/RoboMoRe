import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Reward for the forward velocity with an additional term that rewards maintaining speed over time
    persistent_velocity_reward = self._forward_reward_weight * x_velocity * (1 + np.clip(x_velocity / 2.0, 0, 1))
    
    # Encouragement for steady state hopping: rewarding consistency in action with a small penalty for deviation
    if hasattr(self, 'previous_action'):
        consistency_reward = -np.sum(np.abs(action - self.previous_action)) * 0.1  # Penalty for large deviations promotes steadiness
    else:
        consistency_reward = 0  # No penalty on the first step
        
    # Penalizing excessive control use while also encouraging efficient torque application
    control_penalty = self._ctrl_cost_weight * np.sum(np.square(action))
    
    # Healthy reward for remaining in a healthy state
    health_bonus = self.healthy_reward

    # Total reward calculation: aim for forward velocity, maintain consistency, and minimize control cost
    total_reward = persistent_velocity_reward + consistency_reward - control_penalty + health_bonus

    # Reward information for debugging
    reward_info = {
        'persistent_velocity_reward': persistent_velocity_reward,
        'consistency_reward': consistency_reward,
        'control_penalty': control_penalty,
        'health_bonus': health_bonus,
        'total_reward': total_reward
    }

    return total_reward, reward_info

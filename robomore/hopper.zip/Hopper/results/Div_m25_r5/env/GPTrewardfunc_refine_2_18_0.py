import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Reward for forward velocity with a squared component for emphasizing faster speeds
    forward_speed_reward = self._forward_reward_weight * (x_velocity ** 2)
    
    # Encourage maintaining the right rhythm by rewarding consistent control inputs between steps
    if hasattr(self, 'previous_action'):
        rhythmic_smoothness_reward = -np.sum(np.abs(action - self.previous_action))  # Penalty for changes in action
    else:
        rhythmic_smoothness_reward = 0  # No penalty on the first step
    
    # Store the current action for the next step comparison
    self.previous_action = action

    # Penalize for high control efforts to promote energy efficiency
    control_penalty = self._ctrl_cost_weight * np.sum(np.square(action))
    
    # Reward for staying within a healthy position
    health_bonus = self.healthy_reward
    
    # Reward for achieving a target forward velocity threshold to encourage more aggressive forward motion
    target_velocity_bonus = 0.0
    if x_velocity > 2.0:  # Set a target threshold for bonus
        target_velocity_bonus = 2.0 * (x_velocity - 2.0)  # Linear bonus for exceeding the target

    # Total reward calculation
    total_reward = (
        forward_speed_reward + 
        rhythmic_smoothness_reward - 
        control_penalty + 
        health_bonus + 
        target_velocity_bonus
    )

    # Prepare the reward information for monitoring and debugging
    reward_info = {
        'forward_speed_reward': forward_speed_reward,
        'rhythmic_smoothness_reward': rhythmic_smoothness_reward,
        'control_penalty': control_penalty,
        'health_bonus': health_bonus,
        'target_velocity_bonus': target_velocity_bonus,
        'total_reward': total_reward
    }

    return total_reward, reward_info

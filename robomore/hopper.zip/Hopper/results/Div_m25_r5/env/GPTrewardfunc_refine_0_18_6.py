import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Encourage maximum forward movement with a stronger reward for high velocities (cubic scaling)
    forward_reward = self._forward_reward_weight * (x_velocity ** 3)

    # Introduce a smoothness check to discourage rapid changes in control inputs
    if hasattr(self, 'previous_action'):
        smoothness_penalty = np.sum(np.abs(action - self.previous_action)) * self._ctrl_cost_weight
    else:
        smoothness_penalty = 0
    
    # Store current action for future comparisons
    self.previous_action = action

    # Healthy state reward for maintaining the correct posture and bounds
    health_bonus = self.healthy_reward

    # Aggregate rewards and penalties
    total_reward = forward_reward - smoothness_penalty + health_bonus
    
    # Create a dictionary to store individual components of the reward for debugging and monitoring
    reward_info = {
        'forward_reward': forward_reward,
        'smoothness_penalty': smoothness_penalty,
        'health_bonus': health_bonus,
        'total_reward': total_reward
    }

    return total_reward, reward_info

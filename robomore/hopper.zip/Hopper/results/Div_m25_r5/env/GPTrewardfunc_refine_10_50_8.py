import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Encourage forward velocity as the primary goal
    forward_reward = self._forward_reward_weight * x_velocity
    
    # Reward for being in a healthy state
    healthy_reward = self.healthy_reward
    
    # Introduce a penalty for time taken to encourage faster hopping
    # This could be a small negative reward for each step taken
    time_penalty = -0.02  # Increased penalty for slow progress
    
    # Control cost penalty, but apply a square-root scale to reduce its harshness on control
    control_effort = self.control_cost(action)
    ctrl_cost = np.sqrt(control_effort)  # Reduced impact of control cost

    # Total reward calculation incorporating forward movement, health, time penalty and control cost
    reward = forward_reward + healthy_reward + time_penalty - ctrl_cost

    # Dictionary to provide detailed reward components
    reward_info = {
        "reward_forward": forward_reward,
        "reward_ctrl": -ctrl_cost,
        "reward_survive": healthy_reward,
        "reward_time": time_penalty,
    }

    return reward, reward_info

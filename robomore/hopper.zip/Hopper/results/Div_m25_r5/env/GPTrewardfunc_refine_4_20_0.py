import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Encourage continuous forward movement with a reward that increases with velocity
    max_possible_velocity = 10.0  # Assuming a max velocity based on environment observation
    velocity_reward = self._forward_reward_weight * (x_velocity / max_possible_velocity)

    # Reward for maintaining a steady hopping rhythm, penalizing large deviations in action
    if hasattr(self, 'previous_action'):
        rhythmic_reward = -0.5 * np.sum(np.square(action - self.previous_action))
    else:
        rhythmic_reward = 0  # No penalty on the first action

    # Store current action for next step comparison
    self.previous_action = action

    # Control cost to minimize excessive torque application
    control_penalty = self._ctrl_cost_weight * np.sum(np.square(action))

    # Health bonus to keep the hopper in a viable state
    health_bonus = self.healthy_reward

    # Total reward calculation: combine components for a comprehensive scoring
    total_reward = velocity_reward + rhythmic_reward - control_penalty + health_bonus

    # Ensure the total reward is bounded (can be adjusted if necessary)
    total_reward = np.clip(total_reward, -1.0, 1.0)

    # Reward information for detailed analysis
    reward_info = {
        'velocity_reward': velocity_reward,
        'rhythmic_reward': rhythmic_reward,
        'control_penalty': control_penalty,
        'health_bonus': health_bonus,
        'total_reward': total_reward
    }

    return total_reward, reward_info

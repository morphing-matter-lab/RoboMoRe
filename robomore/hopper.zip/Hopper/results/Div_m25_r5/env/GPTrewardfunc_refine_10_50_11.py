import numpy as np 
def _get_rew(self, x_velocity: float, action):
    # Forward reward based on x_velocity, weighted by a factor
    forward_reward = self._forward_reward_weight * x_velocity
    
    # Healthy reward based on the robot's health status
    healthy_reward = self.healthy_reward 
    
    # Encourage the robot to maintain balance by rewarding for z-position
    # This provides positive reinforcement for being upright
    z_reward = 1.0 if self.data.qpos[1] > 0.7 else 0.0
    
    # Introduce a velocity reward to encourage jumping with appropriate speed
    velocity_reward = 0.5 * np.clip(x_velocity, 0, 5.0)  # Normalizes velocity for more steady rewards
    
    # Control cost to penalize excessive torques
    control_effort = self.control_cost(action)
    
    # Small negative penalty over time to encourage faster trials without severely punishing the agent
    time_penalty = -0.01
    
    # Combining all parts of the rewards into a total reward
    reward = forward_reward + healthy_reward + z_reward + velocity_reward + time_penalty - control_effort
    
    # Creating a detailed reward information dictionary for analysis
    reward_info = {
        "reward_forward": forward_reward,
        "reward_health": healthy_reward,
        "reward_z": z_reward,
        "reward_velocity": velocity_reward,
        "reward_ctrl": -control_effort,
        "reward_time": time_penalty,
    }

    return reward, reward_info

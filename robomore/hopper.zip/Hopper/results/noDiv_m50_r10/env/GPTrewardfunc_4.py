def _get_rew(self, x_velocity: float, action):
    # Encourage forward movement (right direction). Higher velocity yields higher reward.
    forward_reward = self._forward_reward_weight * x_velocity

    # Discourage excessive control effort to save energy and prevent erratic behavior.
    control_cost = self.control_cost(action)

    # Include a constant reward if the hopper remains healthy (upright and within specified state limits).
    healthy_reward = self.healthy_reward

    # Total reward is a combination of the rewards and costs.
    reward = forward_reward - control_cost + healthy_reward

    # Debugging information to track different components of the reward.
    reward_info = {
        'forward_reward': forward_reward,
        'control_cost': control_cost,
        'healthy_reward': healthy_reward
    }

    return reward, reward_info

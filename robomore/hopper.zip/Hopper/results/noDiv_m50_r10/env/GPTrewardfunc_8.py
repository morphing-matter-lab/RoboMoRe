def _get_rew(self, x_velocity: float, action):
    # Reward for forward velocity
    forward_reward = self._forward_reward_weight * x_velocity
    
    # Penalize control effort to prevent too much torque which can cause unstable behavior
    control_penalty = self.control_cost(action)
    
    # Add a reward for staying healthy (optional)
    if self.is_healthy:
        health_reward = self.healthy_reward
    else:
        health_reward = 0

    # Total reward is a combination of forward movement reward, control penalty, and health status
    total_reward = forward_reward - control_penalty + health_reward
    
    # Collect reward components for debugging and other info purposes
    reward_info = {
        'forward_reward': forward_reward,
        'control_penalty': control_penalty,
        'health_reward': health_reward,
        'total_reward': total_reward
    }
    
    return total_reward, reward_info

def _get_rew(self, x_velocity: float, action):
    # Velocity reward for moving in the forward direction
    forward_reward = self._forward_reward_weight * x_velocity
  
    # Cost of using high magnitude control inputs (actuator effort)
    control_penalty = self.control_cost(action)
  
    # Reward for maintaining a healthy state
    health_reward = self.healthy_reward
  
    # Total reward combines all the above components
    reward = forward_reward + health_reward - control_penalty
  
    # Reward info provides insights into the contributions of each reward component
    reward_info = {
        "forward_reward": forward_reward,
        "control_penalty": control_penalty,
        "health_reward": health_reward
    }

    return reward, reward_info

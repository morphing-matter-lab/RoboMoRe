def _get_rew(self, x_velocity: float, action):
    # Encourage the hopper to hop as fast as possible in the forward direction
    forward_reward = self._forward_reward_weight * x_velocity

    # Penalize the hopper for using too much torque in its actions
    control_cost = self.control_cost(action)

    # Provide a reward for maintaining a healthy state ('is_healthy' is defined in the class)
    healthy_reward = self.healthy_reward

    # Combine the rewards and costs into a single reward
    reward = forward_reward + healthy_reward - control_cost

    # Information about rewards for debugging and analysis
    reward_info = {
        "forward_reward": forward_reward,
        "control_cost": control_cost,
        "healthy_reward": healthy_reward
    }

    return reward, reward_info

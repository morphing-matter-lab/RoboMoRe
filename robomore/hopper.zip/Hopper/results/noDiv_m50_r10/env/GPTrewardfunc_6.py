def _get_rew(self, x_velocity: float, action):
    # Forward velocity reward: incentivizing the hopper to move as fast as possible
    forward_reward = self._forward_reward_weight * x_velocity

    # Control cost: penalizes large actions to encourage smooth and efficient movements
    control_cost = self.control_cost(action)

    # Healthy reward: gives a bonus for keeping the hopper in a healthy and stable configuration
    healthy_bonus = self.healthy_reward

    # Combining all parts of the reward
    reward = forward_reward - control_cost + healthy_bonus

    # Reward info for debugging and analysis
    reward_info = {
        'forward_reward': forward_reward,
        'control_cost': control_cost,
        'healthy_reward': healthy_bonus
    }

    return reward, reward_info

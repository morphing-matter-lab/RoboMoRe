def _get_rew(self, x_velocity: float, action):
    # Encourage faster forward movement
    forward_reward = self._forward_reward_weight * x_velocity

    # Penalize excessive control effort to keep movements smooth and efficient
    control_penalty = self.control_cost(action)

    # Encourage remaining healthy to not fall or reach an unhealthy state
    health_reward = self.healthy_reward

    # Calculate total reward
    reward = forward_reward + health_reward - control_penalty

    # Reward breakdown for analysis and debugging
    reward_info = {
        'forward_reward': forward_reward,
        'control_penalty': control_penalty,
        'health_reward': health_reward
    }

    return reward, reward_info

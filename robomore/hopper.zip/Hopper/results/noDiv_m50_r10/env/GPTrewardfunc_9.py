def _get_rew(self, x_velocity: float, action):
    # Reward for moving forward, the faster the better
    forward_reward = self._forward_reward_weight * x_velocity

    # Cost of control is the sum of squared actions to encourage smooth and small actions
    control_cost = self.control_cost(action)

    # A constant reward when the hopper is healthy to encourage staying healthy
    healthy_bonus = self.healthy_reward

    # Total reward combines all these factors
    reward = forward_reward - control_cost + healthy_bonus

    # Information dictionary about the reward components
    reward_info = {
        'forward_reward': forward_reward,
        'control_cost': control_cost,
        'healthy_bonus': healthy_bonus
    }

    return reward, reward_info

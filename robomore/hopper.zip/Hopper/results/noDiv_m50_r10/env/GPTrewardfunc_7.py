def _get_rew(self, x_velocity: float, action):
    # Reward for forward movement
    forward_reward = self._forward_reward_weight * x_velocity

    # Penalize for control usage to achieve energy efficiency
    control_cost = self.control_cost(action)

    # Reward for staying healthy (or a penalty if not)
    healthy_reward = self.healthy_reward

    # Calculate the total reward
    reward = forward_reward + healthy_reward - control_cost

    # Compile the reward components for debugging or analysis
    reward_info = {
        'forward_reward': forward_reward,
        'control_cost': control_cost,
        'healthy_reward': healthy_reward
    }
    
    return reward, reward_info

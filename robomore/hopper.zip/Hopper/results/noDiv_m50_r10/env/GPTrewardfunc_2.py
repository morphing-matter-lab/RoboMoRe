def _get_rew(self, x_velocity: float, action):
    # Forward reward encouraging speed in the positive x direction
    forward_reward = self._forward_reward_weight * x_velocity

    # Calculate the control cost (penalize for high energy/torque use)
    control_cost = self.control_cost(action)

    # Combine rewards and costs
    reward = self.healthy_reward + forward_reward - control_cost
    
    # Collecting reward info for debugging and analysis
    reward_info = {
        "forward_reward": forward_reward,
        "control_cost": control_cost,
        "healthy_reward": self.healthy_reward,
    }
    
    return reward, reward_info

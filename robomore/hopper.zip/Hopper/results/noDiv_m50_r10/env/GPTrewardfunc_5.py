def _get_rew(self, x_velocity: float, action):
    # Reward for moving forward, the faster the better
    forward_reward = self._forward_reward_weight * x_velocity

    # Cost of control to minimize the use of torques (saving energy)
    control_cost = self.control_cost(action)

    # Reward for being healthy (not falling down)
    healthcare_reward = self.healthy_reward

    # Total reward calculation
    reward = forward_reward - control_cost + healthcare_reward

    # Detailed information about rewards for possible debugging or analysis
    reward_info = {
        'forward_reward': forward_reward,
        'control_cost': control_cost,
        'healthcare_reward': healthcare_reward
    }

    return reward, reward_info

import numpy as np
def _get_rew(self, x_velocity: float, action):
    # Reward for energy-efficient hopping: encourages the agent to reach optimal velocities
    # with less fluctuation and control effort
    optimal_velocity = 3.0  # Define an optimal velocity target for efficient and fast movement
    velocity_efficiency_reward = -np.abs(x_velocity - optimal_velocity)  # Maximize reward when closer to the optimal velocity

    # Incorporate an exponential term to incentivize exceeding the optimal speed slightly, rewarding high-speed efficiency
    if x_velocity > optimal_velocity:
        high_speed_bonus = np.exp((x_velocity - optimal_velocity) / 2) - 1
    else:
        high_speed_bonus = 0

    # Penalize large and rapid changes in action, encouraging smoother transitions between actions
    if hasattr(self, 'previous_action'):
        smoothness_penalty = self._ctrl_cost_weight * np.sum(np.square(action - self.previous_action))
    else:
        smoothness_penalty = 0
    self.previous_action = action

    # Health bonus for maintaining a healthy posture and joint angles
    health_bonus = self.healthy_reward

    # Calculate total reward incorporating efficiency and health
    total_reward = velocity_efficiency_reward + high_speed_bonus - smoothness_penalty + health_bonus

    # Detailed reward components for analysis and debugging
    reward_info = {
        'velocity_efficiency_reward': velocity_efficiency_reward,
        'high_speed_bonus': high_speed_bonus,
        'smoothness_penalty': smoothness_penalty,
        'health_bonus': health_bonus,
        'total_reward': total_reward
    }

    return total_reward, reward_info

import numpy as np
def _get_rew(self, x_velocity: float, action):
    # Reward for forward movement
    forward_reward = self._forward_reward_weight * x_velocity

    # Penalty for using too much control input (effort)
    control_penalty = self._ctrl_cost_weight * np.sum(np.square(action))

    # Healthy reward bonus for staying within the defined healthy parameters
    health_bonus = self.healthy_reward

    # Combine rewards and penalties to form the total reward
    total_reward = forward_reward - control_penalty + health_bonus
    
    # Create a dictionary to store individual components of the reward for debugging and monitoring
    reward_info = {
        'forward_reward': forward_reward,
        'control_penalty': control_penalty,
        'health_bonus': health_bonus,
        'total_reward': total_reward
    }

    return total_reward, reward_info

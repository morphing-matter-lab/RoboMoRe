import numpy as np
def _get_rew(self, x_velocity: float, action):
    # Encourage a bouncing gait, which is a repetitive hopping pattern where recovery time between hops is minimized
    # This style will test the robot's ability to dynamically balance and reposition its leg for the next move efficiently

    # Reward for maintaining consistent, high-amplitude hops
    bounce_amplitude_reward = -np.var(self.data.qpos[1:])  # Low variance in joint positions indicates consistent positioning

    # Reward based upon x_velocity, but modify such that only sufficiently quick movements are rewarded
    # Ensure exponential growth in reward as velocity aids in achieving robust and quick movement
    if x_velocity > 1.0:  # Threshold to prevent minimal forward motion from getting reward
        forward_momentum_reward = np.exp(x_velocity - 1) - 1
    else:
        forward_momentum_reward = 0

    # Punish large and jerky controls to encourage smooth transitions and efficient energy usage
    control_smoothness_penalty = np.sum(np.abs(np.diff(action)))  # Increment penalty for each large difference between successive actions

    # Health reward for sustaining an undamaged and upright posture
    health_stability_bonus = self.healthy_reward

    # Total reward calculation, combining the incentives and penalties
    total_reward = bounce_amplitude_reward + forward_momentum_reward - control_smoothness_penalty + health_stability_bonus

    # Assembling detailed information about reward components for debugging and performance analysis
    reward_info = {
        'bounce_amplitude_reward': bounce_amplitude_reward,
        'forward_momentum_reward': forward_momentum_reward,
        'control_smoothness_penalty': control_smoothness_penalty,
        'health_stability_bonus': health_stability_bonus,
        'total_reward': total_reward
    }

    return total_reward, reward_info

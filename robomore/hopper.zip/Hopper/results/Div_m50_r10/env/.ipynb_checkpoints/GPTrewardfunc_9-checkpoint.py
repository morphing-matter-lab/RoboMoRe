import numpy as np
def _get_rew(self, x_velocity: float, action):
    # Encourage continuous forward motion with the aim of achieving a fluid, non-stop progression pattern
    # Reward linearly increasing with forward velocity, emphasizing speed but with diminishing returns for ultra-high speeds
    continuous_motion_reward = self._forward_reward_weight * np.log(1 + x_velocity)

    # Penalize any backward movement by making the reward strictly dependent on positive velocities
    if x_velocity < 0:
        reverse_motion_penalty = -5  # A significant penalty for moving in the reverse direction
    else:
        reverse_motion_penalty = 0

    # Control penalty discouraging excessive use of torque to promote efficiency in energy consumption
    control_efficiency_penalty = self._ctrl_cost_weight * np.sum(np.square(action))

    # Bonus for maintaining a healthily configured mechanism according to the game physics
    health_maintenance_bonus = self.healthy_reward

    # Calculate the total reward by integrating all components
    total_reward = continuous_motion_reward + reverse_motion_penalty - control_efficiency_penalty + health_maintenance_bonus

    # Reward info for detailed decomposition and analysis during training phases
    reward_info = {
        'continuous_motion_reward': continuous_motion_reward,
        'reverse_motion_penalty': reverse_motion_penalty,
        'control_efficiency_penalty': control_efficiency_penalty,
        'health_maintenance_bonus': health_maintenance_bonus,
        'total_reward': total_reward
    }

    return total_reward, reward_info

import numpy as np
def _get_rew(self, x_velocity: float, action):
    # Reward for zigzag movement: alternating torque directions to encourage a side-to-side motion behavior
    if hasattr(self, 'previous_action'):
        zigzag_reward = np.sum(np.abs(action - self.previous_action))  # Rewarding change in action values
    else:
        zigzag_reward = 0  # No reward on the first step

    # Store the current action to evaluate in the next step
    self.previous_action = action

    # Direct reward component for forward speed, using a linear scale
    forward_speed_reward = self._forward_reward_weight * x_velocity

    # Applying exponential to x_velocity ensures rewards scale up beneficially for higher speeds
    exponential_speed_boost = np.exp(x_velocity) - 1

    # Control effort penalty to prevent excessive use of actuation power
    action_cost_penalty = self._ctrl_cost_weight * np.sum(np.square(action))

    # Continuous health bonus to foster staying within designated healthy state parameters
    health_bonus = self.healthy_reward

    # Compose the total reward: mix of strategy-specific (zigzag) and general performance measures (forward speed, health)
    total_reward = zigzag_reward + forward_speed_reward + exponential_speed_boost - action_cost_penalty + health_bonus

    # Building a dictionary for detailed reward components for debug and analysis
    reward_info = {
        'zigzag_reward': zigzag_reward,
        'forward_speed_reward': forward_speed_reward,
        'exponential_speed_boost': exponential_speed_boost,
        'action_cost_penalty': action_cost_penalty,
        'health_bonus': health_bonus,
        'total_reward': total_reward
    }

    return total_reward, reward_info

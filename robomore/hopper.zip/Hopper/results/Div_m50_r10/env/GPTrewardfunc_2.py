import numpy as np
def _get_rew(self, x_velocity: float, action):
    # Encourage hopping with consistent rhythmic patterns by rewarding consistency in action magnitudes across steps
    if hasattr(self, 'previous_action'):
        rhythmic_consistency_reward = -np.sum(np.abs(action - self.previous_action))  # Encourages similar successive actions
    else:
        rhythmic_consistency_reward = 0  # No penalty on the first step
    
    # Storing current action to compare in the next step
    self.previous_action = action

    # Reward forward motion with a power bonus encouraging more dynamic (faster) hops
    dynamic_forward_reward = self._forward_reward_weight * x_velocity**2  # Squaring the velocity emphasizes higher speeds more

    # Minimize control costs to encourage efficient use of energy
    control_penalty = self._ctrl_cost_weight * np.sum(np.square(action))

    # Bonus for maintaining a healthy robot configuration
    health_bonus = self.healthy_reward

    # Total reward calculation
    total_reward = dynamic_forward_reward + rhythmic_consistency_reward - control_penalty + health_bonus

    # Prepare information dictionary for debugging and analysis
    reward_info = {
        'dynamic_forward_reward': dynamic_forward_reward,
        'rhythmic_consistency_reward': rhythmic_consistency_reward,
        'control_penalty': control_penalty,
        'health_bonus': health_bonus,
        'total_reward': total_reward
    }

    return total_reward, reward_info

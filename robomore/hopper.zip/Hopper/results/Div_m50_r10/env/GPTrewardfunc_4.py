import numpy as np
def _get_rew(self, x_velocity: float, action):
    # Reward for maintaining a healthy balance
    balance_reward = self.healthy_reward

    # Reward for velocity, encouraging the hopper to move forward efficiently
    velocity_reward = self._forward_reward_weight * x_velocity

    # Penalize rapid variations in torque applications to encourage smoother motion
    if hasattr(self, 'previous_action'):
        smoothness_penalty = np.sum(np.square(action - self.previous_action))
    else:
        smoothness_penalty = 0
    self.previous_action = action

    # Control usage penalty to discourage excessive energy expenditure
    control_penalty = self._ctrl_cost_weight * np.sum(np.square(action))

    # Full reward calculation: encourage forward movement and health, penalize jerkiness and high control cost
    total_reward = balance_reward + velocity_reward - smoothness_penalty - control_penalty

    # Reward information breakdown for monitoring and debugging
    reward_info = {
        'balance_reward': balance_reward,
        'velocity_reward': velocity_reward,
        'smoothness_penalty': smoothness_penalty,
        'control_penalty': control_penalty,
        'total_reward': total_reward
    }

    return total_reward, reward_info

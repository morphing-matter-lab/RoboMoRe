import numpy as np
def _get_rew(self, x_velocity: float, action):
    # Reward for maintaining a high velocity with an emphasis on sustainability
    # Using exponential function to heavily favor higher speeds
    exponential_velocity_reward = self._forward_reward_weight * np.exp(x_velocity / 2) - 1

    # Encourage efficient use of torque by rewarding lower absolute values and penalizing spikes in control actions
    # Calculate the average torque to measure how smoothly and sparingly the torques are applied
    mean_torque = np.mean(np.abs(action))
    torque_efficiency_reward = -mean_torque

    # Penalty for high fluctuations in action, which discourage erratic behavior and promote smooth transitions
    if hasattr(self, 'previous_action'):
        action_fluctuation_penalty = self._ctrl_cost_weight * np.sum(np.square(action - self.previous_action))
    else:
        action_fluctuation_penalty = 0
    self.previous_action = action

    # Health of the hopper: reward for not only being upright but also for consistent z-height to avoid falling/collapsing
    health_reward = self.healthy_reward

    # Composite total reward combining all the designed elements
    total_reward = exponential_velocity_reward + torque_efficiency_reward - action_fluctuation_penalty + health_reward

    # Prepare reward info for detailed insight into the contribution of each component;
    # useful for debugging and understanding specific behaviors encouraged or penalized.
    reward_info = {
        'exponential_velocity_reward': exponential_velocity_reward,
        'torque_efficiency_reward': torque_efficiency_reward,
        'action_fluctuation_penalty': action_fluctuation_penalty,
        'health_reward': health_reward,
        'total_reward': total_reward
    }

    return total_reward, reward_info

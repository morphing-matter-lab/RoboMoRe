import numpy as np
def _get_rew(self, x_velocity: float, action):
    # Reward for high speed with an emphasis on maintaining high continuous speeds
    speed_reward = self._forward_reward_weight * np.log(1 + np.abs(x_velocity))

    # Penalize large, rapid changes in torques to enforce smoother motions
    if hasattr(self, 'previous_action'):
        smoothness_penalty = self._ctrl_cost_weight * np.sum(np.square(action - self.previous_action))
    else:
        smoothness_penalty = 0
    self.previous_action = action

    # Penalize frequent oscillatory movements: if the direction of torque changes too frequently it is inefficient
    if hasattr(self, 'previous_direction'):
        directional_change_penalty = np.sum(np.abs(np.sign(action) - np.sign(self.previous_direction))) * 0.1
    else:
        directional_change_penalty = 0
    self.previous_direction = np.sign(action)

    # Reward for keeping the hopper in a healthy state
    health_bonus = self.healthy_reward

    # Calculate the composite total reward
    total_reward = speed_reward - smoothness_penalty - directional_change_penalty + health_bonus

    # Reward information for monitoring purposes
    reward_info = {
        'speed_reward': speed_reward,
        'smoothness_penalty': smoothness_penalty,
        'directional_change_penalty': directional_change_penalty,
        'health_bonus': health_bonus,
        'total_reward': total_reward
    }

    return total_reward, reward_info

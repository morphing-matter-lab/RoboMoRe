import numpy as np 
def _get_rew(self, x_velocity: float, action):
    forward_reward = np.exp(x_velocity) - 1  # Normalize forward reward using exponential transformation
    healthy_reward = np.exp(self.healthy_reward) - 1  # Normalize healthy reward using exponential transformation

    # Normalize and combine rewards
    rewards = forward_reward + healthy_reward

    # Calculate and normalize control cost
    ctrl_cost = np.exp(self.control_cost(action)) - 1

    # Calculate and normalize contact cost
    contact_cost = np.exp(self.contact_cost) - 1

    # Combine costs
    costs = ctrl_cost + contact_cost

    # Calculate total reward
    reward = rewards - costs

    reward_info = {
        "reward_forward": forward_reward,
        "reward_ctrl": -ctrl_cost,  # Apply negative sign to show it as a cost
        "reward_contact": -contact_cost,  # Apply negative sign to show it as a cost
        "reward_survive": healthy_reward,
    }

    return reward, reward_info

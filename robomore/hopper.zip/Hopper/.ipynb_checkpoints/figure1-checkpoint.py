# xvfb-run -s "-screen 0 1400x900x24" python figure1.py 运行这一行就可以得到最终视频了

import time
from design import *
import importlib
import shutil
from utils import *
from openai import OpenAI
from prompts import *
import json
import numpy as np
from gymnasium.envs.robodesign.GPTHopper import GPTHopperEnv

folder_name = "results/figure1"
log_file = os.path.join(folder_name, "parameters.log")
logging.basicConfig(filename=log_file, level=logging.INFO, format="%(asctime)s - %(message)s")

# folder_name = setup_logging(div_flag=True)



morphology = "results/Div_m25_r5/assets/GPTHopper_refine_1_13_fjw.xml"
rewardfunc = "results/Div_m25_r5/env/GPTrewardfunc_5.py"
morphology_index=998
rewardfunc_index=998
parameter = [1.35, 1.15, 0.75, 0.25, 0.2, -0.2, 0.01, 0.025, 0.035, 0.025]


shutil.copy(morphology, "GPTHopper.xml")
shutil.copy(rewardfunc, "GPTrewardfunc.py")

import GPTrewardfunc
importlib.reload(GPTrewardfunc)  # 重新加载模块rewardfunc
from GPTrewardfunc import _get_rew
GPTHopperEnv._get_rew = _get_rew


model_path = Train(morphology_index, rewardfunc_index, folder_name, stage='fine', total_timesteps=1e6)
# model_path = f"results/Div_m25_r5/fine/SAC_morphology{morphology_index}_rewardfunc{rewardfunc_index}_3000000.0steps"
# model_path = Train(morphology_index, rewardfunc_index, folder_name, stage='fine', total_timesteps=1e6)
# fitness, reward = Eva(model_path=model_path, run_steps=100, folder_name=folder_name, video=True, rewardfunc_index = rewardfunc_index, morphology_index = morphology_index)
fitness, _ = Eva_with_qpos_logging(model_path, run_steps=100, video = True, rewardfunc_index=rewardfunc_index, morphology_index=morphology_index)
# fitness, _ = Eva(model_path)
material = compute_hopper_volume(parameter)
efficiency = fitness / material

print(efficiency)
print(fitness)
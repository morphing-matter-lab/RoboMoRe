# xvfb-run -s "-screen 0 1400x900x24" python test.py 运行这一行就可以得到最终视频了

import time
from design import *
import importlib
import shutil
from utils import *
from openai import OpenAI
from prompts import *
import json
import numpy as np
from gymnasium.envs.robodesign.GPTAnt import GPTAntEnv

folder_name = "results/Div_m50_r10"
log_file = os.path.join(folder_name, "video_parameters.log")
logging.basicConfig(filename=log_file, level=logging.INFO, format="%(asctime)s - %(message)s")

# folder_name = setup_logging(div_flag=True)

best_fitness = float('-inf')  
best_morphology = None  
best_rewardfunc = None  
best_reward = None
best_material = None
best_efficiency = None

morphology_nums = 51
rewardfunc_nums = 11

fitness_matrix = np.array([[None for _ in range(morphology_nums)] for _ in range(rewardfunc_nums)])
efficiency_matrix = np.array([[None for _ in range(morphology_nums)] for _ in range(rewardfunc_nums)])
fitness_list = []


parameter_list = [[1.2, 0.9, 0.6, 0.3, 0.3, -0.3, 0.05, 0.04, 0.05, 0.05],
 [1.5, 1.2, 0.8, 0.5, 0.5, -0.5, 0.03, 0.03, 0.03, 0.04],
 [1.0, 0.7, 0.5, 0.2, 0.2, -0.2, 0.04, 0.05, 0.06, 0.07],
 [1.0, 0.6, 0.4, 0.1, 0.1, -0.1, 0.05, 0.04, 0.03, 0.02],
 [1.3, 0.9, 0.4, 0.1, 0.1, -0.1, 0.02, 0.02, 0.04, 0.06],
 [1.8, 1.3, 0.7, 0.2, 0.2, -0.2, 0.01, 0.03, 0.05, 0.06],
 [1.0, 0.8, 0.5, 0.2, 0.18, -0.2, 0.03, 0.02, 0.02, 0.03],
 [1.0, 0.9, 0.6, 0.2, 0.2, -0.2, 0.02, 0.04, 0.06, 0.08],
 [1.5, 1.2, 0.8, 0.4, 0.35, -0.35, 0.02, 0.02, 0.01, 0.05],
 [1.2, 0.8, 0.5, 0.3, 0.25, -0.25, 0.03, 0.05, 0.06, 0.02],
 [1.6, 1.1, 0.7, 0.4, 0.35, -0.35, 0.03, 0.03, 0.03, 0.04],
 [1.4, 0.9, 0.6, 0.2, 0.2, -0.2, 0.01, 0.01, 0.02, 0.04],
 [1.8, 1.1, 0.9, 0.6, 0.55, -0.6, 0.015, 0.015, 0.015, 0.025],
 [1.7, 1.2, 0.8, 0.3, 0.25, -0.25, 0.01, 0.03, 0.04, 0.02],
 [1.0, 0.6, 0.3, 0.1, 0.08, -0.08, 0.015, 0.025, 0.035, 0.045],
 [1.2, 0.5, 0.2, 0.1, 0.12, -0.12, 0.02, 0.015, 0.02, 0.05],
 [1.0, 0.8, 0.2, 0.05, 0.05, -0.05, 0.01, 0.02, 0.03, 0.06],
 [1.8, 0.6, 0.3, 0.05, 0.05, -0.05, 0.025, 0.035, 0.045, 0.02],
 [0.9, 0.4, 0.15, 0.05, 0.05, -0.05, 0.02, 0.03, 0.04, 0.01],
 [1.5, 0.8, 0.5, 0.2, 0.2, -0.2, 0.01, 0.01, 0.01, 0.04],
 [1.4, 0.6, 0.3, 0.1, 0.12, -0.12, 0.015, 0.04, 0.06, 0.02],
 [2.0, 1.0, 0.6, 0.1, 0.15, -0.15, 0.01, 0.02, 0.03, 0.05],
 [0.8, 0.5, 0.4, 0.2, 0.25, -0.25, 0.01, 0.015, 0.02, 0.03],
 [1.1, 0.8, 0.6, 0.2, 0.19, -0.19, 0.015, 0.03, 0.05, 0.02],
 [1.2, 0.4, 0.3, 0.15, 0.15, -0.15, 0.02, 0.04, 0.05, 0.01],
 [1.5, 1.2, 0.9, 0.5, 0.5, -0.5, 0.015, 0.02, 0.025, 0.03],
 [1.0, 0.8, 0.5, 0.1, 0.1, -0.1, 0.02, 0.015, 0.01, 0.06],
 [1.5, 0.7, 0.4, 0.1, 0.1, -0.1, 0.015, 0.025, 0.03, 0.05],
 [1.5, 1.0, 0.4, 0.15, 0.2, -0.2, 0.015, 0.01, 0.035, 0.05],
 [1.5, 1.0, 0.6, 0.3, 0.3, -0.3, 0.015, 0.02, 0.025, 0.03],
 [1.6, 1.2, 0.7, 0.2, 0.25, -0.25, 0.01, 0.04, 0.06, 0.02],
 [1.4, 0.6, 0.4, 0.2, 0.2, -0.35, 0.012, 0.015, 0.018, 0.06],
 [1.0, 0.6, 0.3, 0.05, 0.06, -0.06, 0.01, 0.02, 0.03, 0.05],
 [1.8, 1.0, 0.8, 0.15, 0.15, -0.15, 0.02, 0.02, 0.05, 0.07],
 [1.0, 0.6, 0.25, 0.05, 0.1, -0.1, 0.01, 0.01, 0.04, 0.05],
 [1.0, 0.3, 0.15, 0.05, 0.05, -0.05, 0.015, 0.025, 0.05, 0.1],
 [1.8, 1.2, 0.8, 0.2, 0.15, -0.15, 0.015, 0.04, 0.06, 0.08],
 [1.5, 0.7, 0.3, 0.05, 0.05, -0.05, 0.015, 0.03, 0.07, 0.1],
 [1.8, 1.4, 0.9, 0.3, 0.3, -0.3, 0.012, 0.013, 0.018, 0.065],
 [1.5, 1.0, 0.6, 0.05, 0.05, -0.05, 0.01, 0.02, 0.03, 0.06],
 [1.8, 0.5, 0.2, 0.05, 0.05, -0.05, 0.01, 0.05, 0.1, 0.2],
 [1.2, 0.9, 0.5, 0.1, 0.07, -0.12, 0.02, 0.01, 0.02, 0.08],
 [1.5, 1.0, 0.6, 0.3, 0.35, -0.35, 0.014, 0.018, 0.1, 0.03],
 [1.0, 0.8, 0.5, 0.1, 0.1, -0.1, 0.05, 0.02, 0.01, 0.1],
 [1.2, 0.6, 0.4, 0.15, 0.15, -0.15, 0.015, 0.02, 0.03, 0.04],
 [1.8, 1.4, 1.0, 0.5, 0.6, -0.7, 0.015, 0.02, 0.025, 0.15],
 [1.5, 0.5, 0.2, 0.1, 0.1, -0.15, 0.012, 0.02, 0.04, 0.08],
 [1.4, 0.85, 0.4, 0.05, 0.05, -0.05, 0.015, 0.01, 0.02, 0.03],
 [1.6, 0.5, 0.25, 0.05, 0.05, -0.05, 0.008, 0.015, 0.03, 0.1],
 [1.5, 1.2, 0.6, 0.1, 0.1, -0.3, 0.01, 0.03, 0.05, 0.07],
 [1.5, 0.6, 0.3, 0.1, 0.2, -0.15, 0.008, 0.01, 0.02, 0.06]]

morphology_list = [f'results/Div_m50_r10/assets/GPTHopper_{i}.xml' for i in range(0,51) ]
rewardfunc_list = [f'results/Div_m50_r10/env/GPTrewardfunc_{i}.py' for i in range(0,11)]

material_list = [compute_hopper_volume(parameter) for parameter in parameter_list]


# material_list = [compute_walker_volume(parameter) for parameter in parameter_list]


for i, rewardfunc in enumerate(rewardfunc_list):
    for j, morphology in enumerate(morphology_list):
        # if i in [0]:
        #     continue
        if j not in [21]:
            continue
        print(i, rewardfunc)
        print(j, morphology)
        shutil.copy(morphology, "GPTHopper.xml")
        shutil.copy(rewardfunc, "GPTrewardfunc.py")         

        import GPTrewardfunc
        importlib.reload(GPTrewardfunc)  # 重新加载模块
        from GPTrewardfunc import _get_rew
        GPTAntEnv._get_rew = _get_rew

        # model_path = Train(j,  i, folder_name, total_timesteps=3e6)
        model_path = f"results/Div_m50_r10/coarse/SAC_morphology{j}_rewardfunc{i}_1000000.0steps"
        fitness, reward = Eva(model_path=model_path, run_steps=100, folder_name=folder_name, video=True, rewardfunc_index = i, morphology_index = j)
        material = material_list[0]
        # material = material_list[0]
        efficiency = fitness/material
        fitness_matrix[i][j] = fitness
        efficiency_matrix[i][j] = efficiency
        
        logging.info("___________________finish coarse optimization_____________________")
        logging.info(f"morphology: {j}, rewardfunc: {i}, material cost: {material} reward: {reward} fitness: {fitness} efficiency: {efficiency}")

        if fitness > best_fitness:
            best_fitness = fitness
            best_morphology = morphology
            best_efficiency = efficiency
            best_rewardfunc = rewardfunc
            best_material = material